> Photo-free distribution: the supplied photograph and photographic copies are excluded. Written photo-derived evidence remains secondary evidence. Original image references and its SHA-256 are retained only as provenance; the image is not included. Historical statements about the original package do not describe this derivative. Use this distribution's manifest and metadata.

# Access and collection coverage

Collection date: 2026-09-28. Scope: 38.122.88.139 and 70.182.52.122; photo-named FRED01/FRED02. This is a record of sources attempted, not a claim to have obtained all organizational logs.

| Source | Result | Meaning / remaining requirement |
|---|---|---|
| User photograph | Preserved and transcribed in `evidence-photo/` | Secondary report image, not original event exports. Only the visible portion is available. |
| Local Documents, Downloads, Desktop, OneDrive | Scoped filename and exact IP/device text searches did not locate original case report or log exports | No relevant original local evidence retrieved. Some unrelated files were deliberately not opened. |
| Connected Chrome | No Exabeam or Falcon session in available tab inventory | Need the authenticated work portal or exported evidence. |
| Local MUFG ITO investigations page | Displayed `Investigations could not be loaded. Failed to fetch`; retry initiated but did not yield case records | Zero loaded cases does not mean no cases exist. This is an access failure, not a negative investigation result. |
| Windows Firefox inspection | Computer tool stopped: browser URL policy enforcement unsupported | No Firefox page contents read; no alternative automation used to bypass the restriction. |
| Connected Google Drive | Exact searches for both IPs returned no results; broader DFIR search returned no relevant investigation artifact | A search result does not certify complete tenant coverage. |
| Slack | Connector returned not connected / USER_NOT_LOGGED_IN | Not searched successfully; no negative inference. |
| Exabeam raw events and case attachments | Unavailable in this session | Need originals, exact query/time bounds, pagination/completion counts, and retention dates. |
| CrowdStrike/Falcon raw events and historical host inventory | Unavailable in this session | Need stable host/device IDs, IP history, event times, connection direction, login fields, and retention/export details. |
| Firewall/NAT, router WAN DHCP, edge flow/session logs | Unavailable in this session | Needed to map each public address and port to a specific workstation at each event time. |
| Configuration and change audit logs | Unavailable in this session | Needed to identify public-IP assignment, forwarding/security-rule creation, activation, modification, and removal. |
| Public passive sources | See `public-history/` and `scan-history/` | Record specific observations and service access failures; neither routing nor lack of a scan hit proves endpoint reachability. |

No active target probes or new internet scans were requested. No systems, firewall rules, or cloud access settings were changed. No messages were sent to other people. No evidence was uploaded to public scanning services.

The user was asked where the original authenticated work portal or exports are available. That access remains necessary for a complete organizational-log timeline.
