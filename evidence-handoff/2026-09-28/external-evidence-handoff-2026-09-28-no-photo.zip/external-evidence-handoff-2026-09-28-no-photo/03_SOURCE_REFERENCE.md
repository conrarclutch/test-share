> Photo-free distribution: the supplied photograph and photographic copies are excluded. Written photo-derived evidence remains secondary evidence. Original image references and its SHA-256 are retained only as provenance; the image is not included. Historical statements about the original package do not describe this derivative. Use this distribution's manifest and metadata.

# Offline source reference and interpretation notes

These concise notes were prepared from primary documentation consulted on September 28, 2026. They provide the concepts needed to use the preserved evidence without visiting blocked external sites. They are summaries, not full copies of vendor documentation. Provider access terms, schemas and retention may change; a future query must record its actual entitlement and response.

## Timestamp dictionary

| Field / source | Interpretation in this package |
|---|---|
| Shodan banner `timestamp` | UTC time the banner was collected. An individual service observation; not the host page's retrieval date |
| Netlas response `@timestamp` | Document indexing time, generally near scanning. It is not an exact scanner-start timestamp |
| Netlas `scan_label`, index date, deprecated `scan_date` | Campaign/index context; not the exact time this IP answered |
| RDP NTLM `system_time` | Time reported by the remote endpoint; clock correctness is not independently established |
| Certificate Not Before / Not After | Certificate validity interval; not a public-access interval |
| HTTP Date, cache headers, file modification or retrieval timestamp | Collection/transport/file metadata; not service reachability |
| Photo-transcribed timestamp | The photographed report's event time, pending validation against original logs |

## Scanner sources

**Netlas Responses.** A response document describes a scanned service. Preserve the IP, port, protocol, raw service response, identity fields, document index time, campaign label and exact request. The available catalog holds selected historical campaigns rather than an uninterrupted daily history. Use an explicit requested index and verify the returned label; the default may supply current data. Empty items do not establish historical closure. [Response fields](https://docs.netlas.io/knowledge-base/field-reference/responses/) · [Data collection and indices](https://docs.netlas.io/knowledge-base/data-collection/)

**Netlas access.** The current Community plan is described as personal/non-commercial with 50 requests/day. The preserved rate-limit response gave a reset estimate, not a promise of later access. Work-use entitlement and rate limits are separate issues. Older query previews in the package have NOT_RUN status and must not be ingested as observations. [Plan details](https://netlas.io/pricing/)

**Shodan.** Preserve each service banner's timestamp, not just the overall host page's last-seen date. Standard host views cover recent data; the documented historical host API is limited to up to 90 days and 1,000 banners. Multi-year Trends are aggregates, and cannot substitute for a raw dated response from the target. The included public page supplies the three dated September banners. [Banner schema](https://datapedia.shodan.io/) · [History limits](https://help.shodan.io/mastery/data_timeline) · [API](https://developer.shodan.io/api)

**Censys.** Historical host-service records are separate from current host lookup, DNS history and bulk datasets. The current host-history table gives Free no access, Starter seven days, and paid plans longer access depending on entitlement. Short free DNS history does not imply free historical service banners. Record the actual account entitlement and data type before interpreting availability. [Host history](https://docs.censys.com/docs/platform-historical-data) · [Access tiers](https://docs.censys.com/docs/data-access-tiers-entitlements)

**Rapid7 Sonar.** Its current data service describes commercial access with an account/API key. Old references to unrestricted Open Data downloads should not be relied upon for this operational investigation. SSH/RDP data would be relevant if the organization already has entitled archives; DNS studies alone would not prove an open port. [Current access](https://sonardata.rapid7.com/about/) · [API](https://sonardata.rapid7.com/apihelp/)

## Free network-owner reporting

**Shadowserver.** Free reports are scoped to the recipient's authorized networks and require reviewed access; API access needs a key. SSH/RDP/SMB report timestamps describe probes in UTC. Reports API date filters support backdated requests, but the public documentation does not guarantee that a new recipient can retrieve a year of prior data. Existing archived CSV reports may be particularly useful. [Reporting access](https://www.shadowserver.org/what-we-do/network-reporting/get-reports/) · [API contract](https://github.com/The-Shadowserver-Foundation/api_utils/wiki/API:-Reports-Query)

For an already authorized account, inventory subscribed reports and available dates, obtain full CSVs, and preserve their timestamps and identities. `reports/list` accepts `date` and optional `reports`; `reports/query` uses a `query` dictionary, date bounds and pagination. Queries must match the organization's subscribed scope. Query results have fewer details than full report CSVs. A date in a documentation example does not prove that date remains available now.

## DNS, routing, certificates and web archives

**RIPEstat and registration.** Routing history describes BGP visibility of a network prefix. RDAP/WHOIS describes allocation or registration. Neither establishes a device's assignment, NAT destination, open port or service uptime. Retain the request parameters and returned intervals as network context. [Routing-history API](https://stat.ripe.net/docs/data-api/api-endpoints/routing-history)

**urlscan, Common Crawl and Wayback.** These contain web-related observations/captures. A dated successful fetch can support that particular web observation if the target and response are verified. It cannot establish SSH/RDP/SMB availability. Distinguish the date a scanner page was archived from the service timestamp displayed within that page. A failed archive request is not a completed no-result search. [urlscan search](https://docs.urlscan.io/apis/urlscan-openapi/search) · [Common Crawl index](https://commoncrawl.org/cdxj-index) · [Wayback CDX](https://github.com/internetarchive/wayback/tree/master/wayback-cdx-server)

**Certificate and DNS pivots.** A matching public key/certificate, hostname, serial or name/IP observation can connect records, but shared/cloned identities and address reassignment remain possible. Self-issued RDP certificates may never appear in public certificate-transparency logs. Certificate validity alone cannot backdate internet exposure. The concrete extracted RDP certificate fields and source are in `audit/identity-pivots/identity-enrichment.json`.

## Internal correlation and free local tools

**Windows OpenSSH.** Default host-key material and configuration are normally under `%ProgramData%\ssh`; logging normally uses Windows events, with file logging possible when configured. Collect the retained configuration and existing logs without changing settings or restarting services. Compare the captured ECDSA public host key with the configured local `.pub` file, not a private key. [Configuration](https://learn.microsoft.com/en-us/windows-server/administration/openssh/openssh-server-configuration) · [Logging](https://learn.microsoft.com/en-us/troubleshoot/windows-server/system-management-components/enable-openssh-verbose-logging)

An administrator can fingerprint a preserved/default public host-key file locally with:

```powershell
ssh-keygen -l -E sha256 -f "$env:ProgramData\ssh\ssh_host_ecdsa_key.pub"
```

Adjust the path to the preserved evidence/configuration. A match strengthens identity; a mismatch may reflect rotation, reinstall, another target or a different configured key. This command was not run against a work endpoint in this investigation. [ssh-keygen flags](https://man.openbsd.org/ssh-keygen)

**Windows event interpretation.** Logon success/failure, WFP decisions, service state and firewall/GPO changes are different evidence classes. A permitted connection event alone does not prove a completed authenticated session. Verify audit-policy coverage and source fields; preserve original EVTX and raw XML. The internal handoff and collection request identify the specific sources and conservative query patterns. [WFP auditing](https://learn.microsoft.com/en-us/windows/win32/fwp/auditing-and-logging) · [Get-WinEvent](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.diagnostics/get-winevent)

**Local parsers.** Hayabusa, Chainsaw and Plaso can analyze supported retained evidence, while IVRE can organize imported scans. They do not create historical observations that were never collected or retained. No tool was installed merely to wrap a source whose access was unavailable. [Hayabusa](https://github.com/Yamato-Security/hayabusa) · [Chainsaw](https://github.com/WithSecureLabs/chainsaw) · [Plaso](https://github.com/log2timeline/plaso) · [IVRE](https://doc.ivre.rocks/en/stable/usage/use-cases.html)

The goal is a sourced interval assessment per path and service, with explicit unknowns. Keep every proposed ON/OFF boundary tied to evidence IDs, effective configuration time, stable endpoint identity and documented coverage.
