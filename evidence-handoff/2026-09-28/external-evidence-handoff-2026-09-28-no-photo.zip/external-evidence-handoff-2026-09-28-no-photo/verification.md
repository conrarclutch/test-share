> Photo-free distribution: the supplied photograph and photographic copies are excluded. Written photo-derived evidence remains secondary evidence. Original image references and its SHA-256 are retained only as provenance; the image is not included. Historical statements about the original package do not describe this derivative. Use this distribution's manifest and metadata.

# Evidence verification

Two independent readers checked the photograph and the recovered service data. The photo copy's SHA-256 matches the supplied attachment. The three photographed outbound rows retain their original UTC-07 times, destination IPs, direction and secondary-evidence label; two legible event identifiers are carried into the expanded timeline, and the ambiguous identifier is left empty.

Shodan TCP 22, 445 and 3389 timestamps, protocol/banner text and RDP machine name were checked against the saved HTML. Their UTC convention was verified against Shodan Datapedia. The page's Last Seen, HTTP retrieval/cache metadata and InternetDB lookup time are not substituted for per-service scan times.

Historical Netlas JSON was checked for the requested/returned scan label, IP, port, indexed `@timestamp`, RDP NTLM names and remote system clock. Netlas indexing and remote-clock values remain separate from exact Shodan banner-collection times. The April 2026 RDP remote clock is about an hour ahead of indexing, so it is not used as an independently reliable probe timestamp.

The October 2025 and April 2026 Netlas SSH key blobs were compared byte-for-byte with Shodan's September 25 SSH key. All agree. SHA-256 of the decoded 104-byte public key is `27fd815baeab17553d16a39fb8b50171345f6a99425c4f0c6facfafef55cd1ce`. This corroborates a service key over time, not physical host identity or uninterrupted reachability. RDP names and build `10.0.22621` agree; no historical RDP certificate was present for a certificate comparison.

`build-timeline.mjs` regenerates the CSV/JSON from preserved local evidence without network activity. It deduplicates repeated Netlas service/index/timestamp records and suppresses projected undated duplicates when the same index/service has a dated response. It does not infer missing services or calculate continuous exposure durations.

Final package integrity is recorded in `sha256-work.csv`. Hashes verify the collected files have not changed since packaging; they do not authenticate the accuracy of a provider's original observations.
