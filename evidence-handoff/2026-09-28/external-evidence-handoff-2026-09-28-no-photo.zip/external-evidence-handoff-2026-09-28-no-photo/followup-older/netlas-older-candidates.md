> Photo-free distribution: the supplied photograph and photographic copies are excluded. Written photo-derived evidence remains secondary evidence. Original image references and its SHA-256 are retained only as provenance; the image is not included. Historical statements about the original package do not describe this derivative. Use this distribution's manifest and metadata.

# Older Netlas response-index candidates (offline follow-up)

This is a query plan from saved index metadata only. No Netlas query was run, and no host hit is established by the presence of a public index.

The saved response-index inventory was collected at `2026-09-28T18:26:06.0145160Z` from `https://app.netlas.io/api/indices/` (HTTP 200, unauthenticated).
SHA-256: `fb99d0cf2e63026a1a6a829117f21b5d9638ecb3143296dc0b17dab78accb8ec` (`scan-history/both-netlas-indices-no-key.response`). Inventory metadata SHA-256: `3b64e5770ce1c20204aa24a39842e5f39aa972e554e31601905b9589eead24fb`.

## Candidate response indices

| Order | Label | Index ID | Started UTC | Ended UTC | State | Availability | Records |
|---:|---|---:|---|---|---|---|---:|
| 1 | 2025-03-21 | 887 | 2025-03-21T00:00:00Z | 2025-04-22T18:43:12.911000Z | full | public | 711,397,992 |
| 2 | 2024-10-23 | 886 | 2024-10-23T00:00:00Z | 2024-11-15T14:03:33.643000Z | full | public | 851,811,266 |
| 3 | 2024-04-25 | 892 | 2024-04-25T00:00:00Z | 2024-07-04T15:45:10.349000Z | full | public | 656,118,112 |

`availability=public` and `state=full` describe the dataset index, not a result for either target IP. Every per-IP host-hit status remains unknown until a query is run.

## Exact query previews (not run)

Queries below use the saved explicit-index request form. Each is marked `NOT_RUN`; no network access occurred during this follow-up.

### Index 2025-03-21

- `38.122.88.139`: `https://app.netlas.io/api/responses/?q=ip%3A%2238.122.88.139%22&indices=2025-03-21`
- `70.182.52.122`: `https://app.netlas.io/api/responses/?q=ip%3A%2270.182.52.122%22&indices=2025-03-21`

### Index 2024-10-23

- `38.122.88.139`: `https://app.netlas.io/api/responses/?q=ip%3A%2238.122.88.139%22&indices=2024-10-23`
- `70.182.52.122`: `https://app.netlas.io/api/responses/?q=ip%3A%2270.182.52.122%22&indices=2024-10-23`

### Index 2024-04-25

- `38.122.88.139`: `https://app.netlas.io/api/responses/?q=ip%3A%2238.122.88.139%22&indices=2024-04-25`
- `70.182.52.122`: `https://app.netlas.io/api/responses/?q=ip%3A%2270.182.52.122%22&indices=2024-04-25`

Preview only (primary IP `38.122.88.139`, first candidate index):
`https://app.netlas.io/api/responses/?q=ip%3A%2238.122.88.139%22&indices=2025-03-21` — **PREVIEW ONLY; NOT RUN.**

The reported Netlas daily request cap was still active, with an approximate reset of `2026-09-29T00:36:10Z`; this reset estimate was not independently checked here.
The currently known Netlas Community tier is personal/non-commercial only. Public index availability must not be presented as free work-use entitlement; confirm current terms and authorization before organizational queries.

## Verification of the oldest saved Netlas records

The saved October 2025 response-index query returned the earliest Netlas response records currently preserved for `38.122.88.139`. `scan_label`/`scan_date` are `2025-10-22`; the two response-document `@timestamp` values are indexing times, not exact scan-start times:

- RDP/TCP 3389: indexed `2025-10-25T12:30:55.903Z`; target, NetBIOS computer/domain, and DNS computer/domain identify `TEMDFIRPRDFRD01` / `temdfirprdfrd01`. Remote RDP NTLM `system_time` is `2025-10-25T12:30:42+00:00` and remains a separate, untrusted remote clock.
- SSH/TCP 22: indexed `2025-10-25T14:42:39.991Z`; banner `SSH-2.0-OpenSSH_for_Windows_9.5`; captured ECDSA host-key SHA-256 `27fd815baeab17553d16a39fb8b50171345f6a99425c4f0c6facfafef55cd1ce`.

These values match the original response, `scan-history/normalized-events.json`, and the corresponding indexed-time rows in `timeline.csv`. There is no inconsistency in the timestamps or FRED01 response identity. The RDP remote clock is not used as scan time. The SSH key supports continuity of the exposed service key, not proof of a specific physical workstation or a continuous NAT mapping.

Original October query URL: `https://app.netlas.io/api/responses/?q=ip%3A%2238.122.88.139%22&indices=2025-10-22`.
