> Photo-free distribution: the supplied photograph and photographic copies are excluded. Written photo-derived evidence remains secondary evidence. Original image references and its SHA-256 are retained only as provenance; the image is not included. Historical statements about the original package do not describe this derivative. Use this distribution's manifest and metadata.

# Public-IP exposure investigation — preliminary findings

Prepared 2026-09-28. Requested window: 2025-09-28 00:00 UTC-07 (07:00 UTC) through collection cutoff 2026-09-28 18:39:45 UTC (11:39:45 UTC-07). **Status: historical external evidence recovered back to October 2025; internal logs and a complete continuous exposure history remain unavailable.**

## Findings that can be supported now

**38.122.88.139 has external RDP and SSH response records indexed on October 25, 2025**, and additional observations in April and September 2026. The historical RDP records and the recovered [Shodan host page](https://www.shodan.io/host/38.122.88.139) name `TEMDFIRPRDFRD01`, matching FRED01 in the supplied photograph. This establishes evidence of historical public-service responses about eleven months before this collection. It does not establish the original activation date or uninterrupted exposure for those eleven months.

**70.182.52.122 has no confirmed inbound service observation in the evidence recovered so far.** The photograph reports three successful outbound HTTPS connections from FRED02 on September 16. That establishes the report's account of outbound use at those moments; it does not establish inbound RDP, SMB, SSH, public-IP assignment directly to the workstation, or a public-facing listener.

Neither IP has a defensible continuous exposure interval or a confirmed shutdown date from the available evidence. Missing scans, missing telemetry, or access failures do not establish that a host was offline or protected.

## Historical Netlas responses for 38.122.88.139

Explicit historical-index queries returned their requested index labels, rather than silently returning the current index: [October 2025 query](https://app.netlas.io/api/responses/?q=ip%3A%2238.122.88.139%22&indices=2025-10-22) and [April 2026 query](https://app.netlas.io/api/responses/?q=ip%3A%2238.122.88.139%22&indices=2026-04-19). Original JSON bodies and request URLs/HTTP metadata are retained in `scan-history/`.

| Historical index label | Service | Record indexed at (UTC) | Response identity / clock |
|---|---|---|---|
| 2025-10-22 | RDP / TCP 3389 | **2025-10-25T12:30:55.903Z** | NetBIOS computer/target `TEMDFIRPRDFRD01`; server-reported NTLM time `2025-10-25T12:30:42+00:00` |
| 2025-10-22 | SSH / TCP 22 | **2025-10-25T14:42:39.991Z** | `OpenSSH_for_Windows_9.5`; captured ECDSA host key |
| 2026-04-19 | RDP / TCP 3389 | **2026-04-21T19:28:56.883Z** | Same NetBIOS computer/target; server-reported time `2026-04-21T20:29:06+00:00` |
| 2026-04-19 | SSH / TCP 22 | **2026-04-21T22:20:47.460Z** | `OpenSSH_for_Windows_9.5`; captured ECDSA host key |

**Time interpretation matters:** [Netlas's field reference](https://docs.netlas.io/knowledge-base/field-reference/responses/) defines each response document as a scanned service response and `@timestamp` as its indexing time, usually close to scanning. It is not an exact scan-start timestamp. The date-only `scan_date` and `scan_label` values above identify the scan/index campaign and are not used as the host's precise observation date. The NTLM time comes from the remote machine's clock. In the April record that clock is roughly an hour ahead of indexing time, so it must not be silently treated as independently verified scan UTC. Indexing time, remote clock, and precise Shodan scan times occupy separate columns in `timeline.csv`.

The oldest RDP record's indexing time renders as October 25, 2025 at 05:30:55.903 UTC-07; the SSH record renders as 07:42:39.991 UTC-07. These are timestamps attached to historical service evidence, not IP-enable audit events.

**Identity corroboration:** the ECDSA SSH public-key bytes are identical in the October 2025 and April 2026 Netlas records and the September 25 Shodan banner. Independent SHA-256 hashing of the decoded 104-byte key gives `27fd815baeab17553d16a39fb8b50171345f6a99425c4f0c6facfafef55cd1ce`, matching Netlas's fingerprint. That supports the same SSH service key across those observations; cloned keys or a reused forwarding target still require internal identity/NAT validation. The historical RDP responses and September Shodan RDP response also agree on the machine names and build `10.0.22621`. Historical Netlas records did not contain an RDP certificate to compare, and the current certificate's validity dates are not exposure dates.

An additional Netlas result lists **MSRPC / TCP 135**, alongside SSH and RDP, in the index labeled `2026-09-10`. The initial projected result contains no per-service timestamp or machine identity. The index metadata covers a campaign beginning September 10 and still indexing on September 28. This is retained as an undated service-in-index observation, not evidence that TCP 135 was reachable exactly on September 10 or for that whole interval.

## Service observations for 38.122.88.139

| Service | Shodan observation timestamp (UTC) | Evidence | Attribution limit |
|---|---|---|---|
| TCP 3389 / RDP | 2026-09-13T09:06:24 | RDP response includes Target Name, NetBIOS Computer Name, and NetBIOS Domain Name `TEMDFIRPRDFRD01`; FQDN `temdfirprdfrd01` | Strong name match to the photographed report. It is a self-reported service identity; confirm with contemporaneous NAT mapping and a stable endpoint ID. |
| TCP 445 / SMB | 2026-09-24T10:19:19 | SMB response; authentication enabled; SMB version 2 shown | Same public address, but that alone does not prove the port forwarded to the same internal machine. |
| TCP 22 / SSH | 2026-09-25T18:18:50 | Banner reports `OpenSSH_for_Windows_9.5` | Same public address; corroborate target with NAT history and the SSH host-key fingerprint. |

The page-level `Last Seen: 2026-09-25` is not the date of every service observation. Port-specific timestamps above are retained separately. The page is historical scanner evidence, not a live test performed during this investigation. [Shodan's Datapedia](https://datapedia.shodan.io/) defines banner timestamps as UTC. The corresponding UTC-07 times are September 13 at 02:06:24 for RDP, September 24 at 03:19:19 for SMB, and September 25 at 11:18:50 for SSH.

Shodan InternetDB also returned `ports: [3389]` and the tag `self-signed` when collected on September 28. It provides no scan timestamp in that response. Its narrower port list is a separate dataset snapshot, not evidence that ports 22 or 445 subsequently closed. HTTP retrieval time, cache headers, certificate validity dates, and page modification dates are not service-exposure timestamps.

Source preservation: original public responses and request metadata are in `scan-history/` and `public-history/`. The source page's vulnerability labels were not independently validated and are not treated as proof of exploitation or a confirmed vulnerability here.

## FRED02 outbound observations from the photograph

These rows are **secondary evidence transcribed from a photograph**, not raw Falcon logs. All list `msedge.exe`, local address `192.168.8.187`, public egress `70.182.52.122`, successful outcome, and outbound direction.

| UTC-07 | UTC | Destination |
|---|---|---|
| 2026-09-16 05:56:50.541 | 2026-09-16 12:56:50.541Z | 150.171.28.11:443 |
| 2026-09-16 05:56:58.622 | 2026-09-16 12:56:58.622Z | 150.171.109.149:443 |
| 2026-09-16 05:57:08.361 | 2026-09-16 12:57:08.361Z | 150.171.27.11:443 |

The photographed report is titled “Other DFIR devices: internet exposure follow-up” and states a review cutoff of **2026-09-26 15:41:23 UTC-07**. It describes preserved public-source failed-logon evidence for FRED01 without showing its timestamps. It says equivalent inbound exposure is not established for FRED02, and its current state is unresolved. The original case records are needed to validate the summaries and recover earlier dates. Case 15589's score or closed status is not a measure of an exposure window.

The source photo and transcription are preserved in `evidence-photo/`. Its SHA-256 is `B6D403C726E8A6AB29E9A2D19E9EE717DB33B9DDE5C6C2157B1C807139153EB9`.

## One-year coverage and gaps

| Period | What was recovered | What remains unknown |
|---|---|---|
| 2025-09-28 through 2025-10-24 | Network-routing context; the first recovered Netlas campaign is labeled October 22, with service records indexed October 25 | Exact probe time within that campaign, earlier activation, and public-address/device assignment |
| 2025-10-25 | Historical Netlas RDP and SSH records; RDP names FRED01 | Exact scanner time and original activation; continuity to later records |
| 2026-04-21 | Further Netlas RDP and SSH records; RDP names FRED01 | Availability between sampled records; remote clock skew |
| 2026-09-13 | RDP observation on 38.122.88.139 with FRED01 name match | Whether it was reachable before or after this observation |
| 2026-09-16 | Photo-derived FRED02 outbound HTTPS events | Inbound reachability; whether the public address was a shared NAT, forwarding address, or assigned to the host |
| 2026-09-24 and 2026-09-25 | SMB and SSH observations on 38.122.88.139 | Internal target of each port; gaps between observations |
| 2026-09-26 through collection on 2026-09-28 | Photograph review cutoff and public-source retrievals | Current reachability, remediation time, and any later inbound activity |

Historical BGP routes concern network prefixes, not individual host services. RDAP registration dates concern address allocation, not the time a team made a workstation reachable. The routing response's sampling, coverage limits, and any filtered low-visibility routes are documented in the public-source report. No continuous host-availability inference is drawn from them.



## Collection limits and the next evidence needed

The original Exabeam/Falcon work session shown in the photograph was not available in the connected browser. Local searches did not locate its exports. The local investigations application failed to load cases. Connected Drive searches found no relevant IP records; Slack was unconnected. [Access coverage](access-coverage.md) records successful searches, access failures, and unavailable sources separately.

Public-source coverage also has limits. Shodan's unauthenticated history/raw requests returned 401. Netlas's explicit July 22, 2026 index query returned no matching items, which does not establish closure. Its daily request cap then blocked further collection: August 7 and August 21 snapshots and a pre-window March 2025 snapshot were not queried, and an explicit September 10 query returned 429. The earlier latest-index result remains preserved. For 70.182.52.122, a selected six-index Netlas query returned no items; InternetDB, public Shodan, GreyNoise Community, and urlscan returned no matching information. Censys, VirusTotal, FOFA, and ZoomEye did not supply usable service history through the available unauthenticated routes. [The scan-source report](scan-history/scan-report.md) records exact outcomes; these are incomplete observations, not a clean bill of health.

To finish the year-long timeline, obtain the originals through the authenticated work environment:

1. **Edge firewall/NAT and configuration audit history:** public-to-private address/port mappings, allow/deny rules, change actors/times, router WAN leases, interface bindings, and accepted connection/session logs. These establish activation/removal and which host received each public port.
2. **Exabeam and Falcon raw records plus archived storage:** exact IP/hostname searches across the year, stable host IDs, login source/destination fields, network direction, event time versus ingestion time, all pages, and explicit oldest retained timestamps. Include prior FRED01 inquiry evidence and FRED02 Case 15589 context without treating case dates as network dates.
3. **Workstation and relevant cloud/network audit exports:** Windows authentication/firewall/RDP/OpenSSH events and, if these are cloud VMs, public-IP/NIC/security-group association and rule-change records. Include deleted resources and prior names/IPs where identity mapping supports them.
4. **Authenticated historical scan exports if available:** per-port Shodan/Censys or other historical observations, including raw banners and scan timestamps. Paid or authenticated history was not obtained in this collection. Shodan's current [data-timeframe documentation](https://help.shodan.io/mastery/data_timeline) limits standard host results to recent banners and its historical host API to up to 90 days / 1,000 banners; a year cannot be assumed available from that API. Long-term aggregate Trends data is not a substitute for raw per-host observations; historical bulk data or retained organizational scan exports may be needed.

Keep event time, source timezone, collection time, immutable event ID, host identity, translated address/port, result, query bounds, returned count, pagination completion, and retention gaps with every export. An interval may be bounded by verified rule changes plus successful inbound observations; isolated scan observations alone must stay as points.

See [collection-request.md](collection-request.md) for the source-specific collection instructions, [routing/archive checks](public-history/ripe_whois_dns_wayback.md), [scanner-source coverage](scan-history/scan-report.md), and [verification notes](verification.md). No active scans were initiated and no security configuration was changed.
