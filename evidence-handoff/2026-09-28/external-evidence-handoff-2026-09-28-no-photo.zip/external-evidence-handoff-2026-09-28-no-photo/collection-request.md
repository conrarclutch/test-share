> Photo-free distribution: the supplied photograph and photographic copies are excluded. Written photo-derived evidence remains secondary evidence. Original image references and its SHA-256 are retained only as provenance; the image is not included. Historical statements about the original package do not describe this derivative. Use this distribution's manifest and metadata.

# Collection request: historical public-IP exposure timeline

**Targets:** FRED01 (reported name TEMDFIRPRDFRD01), 38.122.88.139; FRED02 (reported name TEMDFIRPRDFRD02), 70.182.52.122, local address 192.168.8.187. Treat names and associations as leads until tied to stable endpoint IDs and dated NAT/IPAM evidence.

**Time window:** include records in **[2025-09-28 07:00:00 UTC, 2026-09-28 18:39:45 UTC)**. Display timestamps as UTC-07 (Arizona). The stop time is the collection cut-off, not the end of September 28. If collection runs later, record the actual stop time and rerun affected queries through it. Preserve event time and ingestion time separately.

## Questions to answer

1. When was each public IP assigned directly to a device or translated/NATed to one? Was it shared, dynamic, or reassigned?
2. During each interval, what inbound services and firewall rules were configured? Which inbound attempts were permitted, blocked, or completed?
3. What outbound traffic used either public source IP, and which private host/device produced it?
4. When did endpoint, firewall, cloud, or logging configuration change? Which gaps reflect retention, disabled collection, access failure, truncation, or a completed query with zero matches?

Keep these findings distinct: **IP/configuration assignment**, **external scan observation**, **inbound traffic**, and **outbound egress only**. A public egress address, outbound HTTPS, DNS/passive-DNS, an IP lookup, or an Internet scan result alone does not prove that an inbound service was continuously reachable. A positive scan supports reachability only for that scanner, time, and protocol; a negative/missed scan does not prove the port was closed between scans.

## Existing leads to validate

The supplied Exabeam/CrowdStrike report describes FRED01 as having public-source failed authentication and public-destination connections. For FRED02, it reports three successful outbound msedge.exe connections on 2026-09-16 around 05:56–05:57 UTC-07, local IP 192.168.8.187, public egress 70.182.52.122, and remote TCP/443 destinations. The report says these do not show when the public IP was activated or whether a public listener existed. It also says the tested CrowdStrike fields had no matching FRED02 telemetry after September 16; obtain the exact query/fields and coverage before interpreting that gap.

A separate InternetDB lookup collected during this investigation reports TCP/3389 for 38.122.88.139 without a scan timestamp, and no match/404 for 70.182.52.122. Preserve the raw lookup response and retrieval time. The first does not date the exposure; the second does not establish historical absence. Subsequently recovered Shodan service observations show RDP on 2026-09-13T09:06:24Z with the FRED01 name, SMB on 2026-09-24T10:19:19Z, and SSH on 2026-09-25T18:18:50Z. See `exposure-findings.md` and `timeline.csv` for the current evidence rather than treating this collection plan as the findings report.

## Collection requests

### 1. Edge, ISP, IPAM, and network telemetry — highest priority

For the full window, export raw firewall/router/NAT records and collector health. Search both public IPs in every source/destination and translated-address field; also search 192.168.8.187, dated hostname/IP/MAC aliases, and any translated addresses found. Include session start/end, direction, original and translated source/destination IP **and ports**, protocol, interface/zone, action/result, rule/policy ID and version, bytes/packets, device identity, event time, and ingest time. Include established/allowed and denied/reset/drop records.

Retrieve historical public-IP assignment/lease and reassignment records (ISP account/static assignment or DHCP, IPAM, router WAN history), DHCP leases, ARP/MAC tables, port-forward/1:1 NAT rules, UPnP mappings if logged, firewall rule/configuration audit history, VPN/remote-access gateway logs, and NetFlow/IPFIX/flow logs. Request dated rule/config snapshots or backups. Tie each public-IP interval to a named endpoint using dated records; do not infer host attribution from current configuration.

**Provider-neutral query logic:** in the identified product's documented query builder, set the UTC interval above and match either public IP against source, destination, translated source, or translated destination. Separately pivot on the private IP, hostnames, MACs, and discovered NAT translations. Use actual field names and address semantics from the source schema; do not paste this logic as vendor syntax. For AWS VPC Flow Logs, documented relevant fields include srcaddr, dstaddr, pkt-srcaddr, and pkt-dstaddr; preserve flow direction/action and NAT gateway context.

For cloud resources, first establish whether either IP was attached to a cloud NIC, NAT gateway, load balancer, or public-IP resource. If so, export control-plane history for public-IP allocation, attach/detach, NIC, firewall/security-group, route, and gateway changes, plus existing flow/NAT logs. Azure Activity Log covers control-plane operations and is retained 90 days by default unless exported. AWS CloudTrail Event History exposes 90 days of management events; longer history requires a configured trail or event data store. Google Cloud Admin Activity records configuration changes; request VPC Flow Logs if enabled. Missing flow logs do not prove no traffic if the source was never configured.

### 2. Windows endpoint evidence

Collect original retained/archived Security.evtx and Windows Firewall/WFP operational logs for both endpoint IDs over the window, plus backup/SIEM copies where local logs have rolled over. Preserve raw EVTX/XML, host clock/time-zone state, log size and oldest/newest record times, effective audit policy/GPO, and export time. Search:

- 4624, 4625, 4648: successful/failed logons and explicit-credential attempts; inspect logon type, target account, source address/port, process, status/substatus.
- 5152–5159: WFP packet drops and connection/listen/bind allow/block activity; inspect application, direction, local/remote address and port, protocol, and filter/rule context.
- 4944–4958, especially 4946–4948, 4950, 4954, 4956: Windows Firewall policy/rule/profile changes.
- 4719, 1102, 1100, 1104, 1108: audit-policy changes, Security log clear, event service shutdown/full/error indicators.

Limits: Windows 4624/4625 are generated on the computer where access was attempted, but source-address fields depend on authentication protocol/context and can be blank. 5156 means WFP permitted a connection; it does not alone prove that a remote public client completed a session. Local 4946–4948 do not fire for rules changed through Group Policy; include domain GPO history/change auditing and correlate 4954 (which can also occur on routine refresh). Confirm relevant audit subcategories were enabled before treating empty results as evidence.

**Read-only query template for a copied EVTX** (adapt the path for each Security EVTX; this returns event XML, including provider fields):

    $start = [datetimeoffset]::Parse('2025-09-28T07:00:00Z').LocalDateTime
    $end   = [datetimeoffset]::Parse('2026-09-28T18:39:45Z').LocalDateTime
    $ids = @(4624,4625,4648,5152,5153,5154,5155,5156,5157,5158,5159,
             4719,1102,1100,1104,1108,4944,4945,4946,4947,4948,4949,
             4950,4951,4952,4953,4954,4956,4957,4958)
    Get-WinEvent -FilterHashtable @{
      Path = '<copied Security.evtx>'
      Id = $ids
      StartTime = $start
      EndTime = $end
    } | Where-Object { $_.TimeCreated -lt $end } |
      ForEach-Object {
        [pscustomobject]@{
          EventId = $_.Id
          RecordId = $_.RecordId
          TimeCreated = $_.TimeCreated
          RawXml = $_.ToXml()
        }
      } | ConvertTo-Json -Depth 5 |
      Set-Content -LiteralPath '<output.json>' -Encoding utf8

This filters only retained contents of the copied log. Preserve the original EVTX before reducing it to matching events. Microsoft documents Get-WinEvent filtering against archived EVTX paths and wevtutil epl export.

### 3. CrowdStrike Falcon

Resolve both reported hostnames, local IP, and public-IP/network-address history to all matching host/device IDs, including hidden, retired, and renamed records. Export IDs, hostname history, last-seen, sensor state/policy, local IP/MAC history, and available host timeline/detections. Search the full window and preserve raw fields, event and ingest times, event IDs, query, pagination/count, and retention limits. Include the report's exact LocalAddressIP4 value; verify remote-address, direction, process, and result field names against the tenant's current event schema before querying them.

Check Falcon Next-Gen SIEM Advanced Event Search if licensed, and the organization's FDR/SIEM data lake and ingestion/collector health if configured. CrowdStrike's public API references expose host search, hidden-host search, network-address history, login history, detections, event streams, and FDR schema/export capabilities; these do not guarantee one-year raw endpoint telemetry retention. Ask the Falcon administrator for the tenant's actual retention/export scope and the precise query behind “no telemetry after September 16.” Do not substitute detections for complete network-flow logs.

### 4. Exabeam

Search all available event sources for both public IPs in every source/destination and raw-log field, plus the private IP and dated host aliases. Include firewall, router/NAT, VPN, DHCP/IPAM, Windows Security/WFP, identity, endpoint, DNS, cloud audit/flow, and Exabeam case/alert activity. Export parsed fields and raw logs, include null fields where offered, and export case/alert histories with linked raw events. Capture source/parser names, saved-search/query ID, event and ingest time, timezone, result count, and export status.

The documented Search Events API POST /search/v2/events requires fields, ISO-8601 startTime/endTime, and a filter; default limit is 3000. Use tenant-verified Query Builder filter/field names (or a copied saved search) in this body template; do not invent vendor field names. Split the interval into adjacent windows if the limit is reached, verify counts, then deduplicate by source event ID. The API describes multi-year searches, but availability depends on tenant retention. Exabeam Search documentation supports zipped CSV exports with parsed fields and optional raw logs.

    {
      "fields": ["<verified time, host, address, direction, event, source, and raw-log fields>"],
      "startTime": "2025-09-28T07:00:00Z",
      "endTime": "2026-09-28T18:39:45Z",
      "limit": 3000,
      "filter": "<validated tenant filter copied from Query Builder>"
    }

### 5. External historical scan evidence

Query Censys host timeline/history and Shodan host history for both IPs over the available portion of the window. Preserve raw responses, scan timestamps, source/vantage, protocol, ports, handshake/banner outcome, and account plan/retention limit. Censys says host-history access varies by plan (Starter: 7 days; Search/Core: 31 days or more) and scans are snapshots; service history can have sampling gaps. Shodan's [current timeframe documentation](https://help.shodan.io/mastery/data_timeline) specifies a recent 30-day view for standard host results and up to 90 days / 1,000 banners for historical host API lookups. Do not promise a one-year raw host history from that API; long-term aggregate Trends data cannot replace event-level proof. These sources corroborate specific scan observations, not continuous uptime. Keep current InternetDB results separate from dated historical observations.

## Timeline and evidence accounting

Create one row per event or state interval with: UTC timestamp and UTC-07 rendering; stable endpoint ID; public IP; private IP/MAC; mapping source; direction; original/translated five-tuple; service/protocol; allowed/blocked/established result; configuration/rule version; source system; record/event ID; query/export reference; and limitation/confidence. Label evidence as IP/configuration assignment, external scan observation, inbound attempt, inbound permitted/established, blocked, outbound only, or coverage/configuration gap.

For every source, record one explicit state: matches found; completed query with zero matches; not retained for requested dates; source not configured; inaccessible/permission denied; query/export failed; truncated/limit hit; or not applicable. Include actual covered start/end, timezone, oldest/newest record, query, result count, and known gaps. Never report a bare “no logs” or “no exposure” without this accounting.

## Primary documentation

- Microsoft: [4624](https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-10/security/threat-protection/auditing/event-4624), [4625](https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-10/security/threat-protection/auditing/event-4625), [Audit Logon](https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-10/security/threat-protection/auditing/audit-logon), [WFP event list](https://learn.microsoft.com/en-us/windows/win32/fwp/auditing-and-logging), [5156](https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-10/security/threat-protection/auditing/event-5156), [Firewall rule audits](https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-10/security/threat-protection/auditing/audit-mpssvc-rule-level-policy-change), [4719](https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-10/security/threat-protection/auditing/audit-audit-policy-change), [1102](https://learn.microsoft.com/en-us/previous-versions/windows/it-pro/windows-10/security/threat-protection/auditing/event-1102), [Get-WinEvent](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.diagnostics/get-winevent?view=powershell-7.5), [wevtutil export](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/wevtutil).
- Cloud: [Azure Activity Log](https://learn.microsoft.com/en-us/azure/azure-monitor/fundamentals/activity-log); AWS [CloudTrail retention](https://docs.aws.amazon.com/awscloudtrail/latest/userguide/how-cloudtrail-works.html) and [VPC Flow Logs](https://docs.aws.amazon.com/vpc/latest/userguide/flow-logs-records-examples.html); Google Cloud [Audit Logs](https://docs.cloud.google.com/logging/docs/audit), [Compute audit logging](https://docs.cloud.google.com/compute/docs/logging/audit-logging), and [VPC Flow Logs](https://docs.cloud.google.com/vpc/docs/flow-logs).
- CrowdStrike: [Hosts API](https://developer.crowdstrike.com/api-reference/collections/hosts/), [Detections](https://developer.crowdstrike.com/api-reference/collections/detects/), [Event Streams](https://developer.crowdstrike.com/api-reference/collections/event-streams/), [FDR schema API](https://developer.crowdstrike.com/api-reference/collections/fdr/).
- Exabeam: [Search Events API](https://developers.exabeam.com/exabeam/reference/search-2) and [Search Guide](https://docs.exabeam.com/private/paligo-output/en/exa-search/all/search-guide/245604-Search_Guide-pdf-en.pdf).
- External scan data: Censys [historical data](https://docs.censys.com/docs/platform-historical-data) and Shodan [Host API](https://developer.shodan.io/api).
