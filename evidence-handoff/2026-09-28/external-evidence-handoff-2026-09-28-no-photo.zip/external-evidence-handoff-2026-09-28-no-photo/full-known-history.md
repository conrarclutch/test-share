> Photo-free distribution: the supplied photograph and photographic copies are excluded. Written photo-derived evidence remains secondary evidence. Original image references and its SHA-256 are retained only as provenance; the image is not included. Historical statements about the original package do not describe this derivative. Use this distribution's manifest and metadata.

# Full recovered history of the investigated public IPs

Prepared September 28, 2026, using all evidence recovered in this investigation through 19:27 UTC. This is the complete recovered history, not a claim of complete historical coverage. Original internal firewall/NAT, Exabeam and Falcon exports remain unavailable.

**38.122.88.139 has historical public RDP and SSH response evidence indexed in October 2025, further records in April 2026, and dated RDP, SMB and SSH observations in September 2026. Its activation date, uninterrupted availability and shutdown date are unknown.**

**70.182.52.122 has report-photo evidence of outbound HTTPS on September 16, 2026. No inbound service observation was recovered for this address.**

## 38.122.88.139 — all dated positive service records

Phoenix is UTC-07 throughout these dates. Netlas indexing times and Shodan banner collection times are different timestamp types; they are explicitly distinguished below.

| Date/time UTC | Phoenix date/time | Service | Source and timestamp type | Observed identity or response |
|---|---|---|---|---|
| 2025-10-25 12:30:55.903 | 2025-10-25 05:30:55.903 | RDP / TCP 3389 | Netlas document indexed; campaign label 2025-10-22 | Target/NetBIOS name TEMDFIRPRDFRD01; DNS name temdfirprdfrd01; build 10.0.22621 |
| 2025-10-25 14:42:39.991 | 2025-10-25 07:42:39.991 | SSH / TCP 22 | Netlas document indexed; campaign label 2025-10-22 | OpenSSH_for_Windows_9.5; captured ECDSA host key |
| 2026-04-21 19:28:56.883 | 2026-04-21 12:28:56.883 | RDP / TCP 3389 | Netlas document indexed; campaign label 2026-04-19 | Same FRED01 response names and build |
| 2026-04-21 22:20:47.460 | 2026-04-21 15:20:47.460 | SSH / TCP 22 | Netlas document indexed; campaign label 2026-04-19 | Same OpenSSH banner and ECDSA public-key bytes |
| 2026-09-13 09:06:24 | 2026-09-13 02:06:24 | RDP / TCP 3389 | Shodan banner collected | Same FRED01 response names and build |
| 2026-09-24 10:19:19 | 2026-09-24 03:19:19 | SMB / TCP 445 | Shodan banner collected | SMB v2; authentication enabled. Internal destination not independently established |
| 2026-09-25 18:18:50 | 2026-09-25 11:18:50 | SSH / TCP 22 | Shodan banner collected | OpenSSH_for_Windows_9.5; same ECDSA public-key bytes as October 2025 and April 2026 |

Preserved originals: [October Netlas response](scan-history/38.122.88.139-netlas-responses-2025-10-22-no-key.response), [April Netlas response](scan-history/38.122.88.139-netlas-responses-2026-04-19-no-key.response), [Shodan host-page response](scan-history/38.122.88.139-shodan-public-host-page.response). Per-request URLs, HTTP status and collection timestamps are in the adjacent `.meta.json` files.

Netlas's `@timestamp` is the document indexing time, not an exact probe time. The October RDP response reports a remote system clock of 12:30:42 UTC; the April response reports 20:29:06 UTC, roughly an hour ahead of its indexing time. These remote clock values are retained separately and are not used as trusted scan timestamps. [Netlas field reference](https://docs.netlas.io/knowledge-base/field-reference/responses/)

The matching SSH identity fingerprint is:

`SHA256:J/2BW66rF1U9FqOfuLUBcTRfaplCXE8Mb6z6/vVc0c4`

It links the observed service key across October, April and September. It does not prove continuous availability or uniquely identify a physical machine: keys can be copied and NAT destinations can change. RDP's repeated FRED01 name is additional corroboration, but contemporaneous public-IP/NAT-to-endpoint mapping is still needed.

## Other 38.122.88.139 records and gaps

| Record or interval | Available evidence | What cannot be concluded |
|---|---|---|
| Before the October 2025 records | No earlier target-specific service response recovered. Catalog entries for response datasets labeled 2024-04-25, 2024-10-23 and 2025-03-21 exist, but those target queries have not been run | The IP or work machine was not necessarily offline or private before October |
| Between October 2025 and April 2026 | No intervening positive service record recovered | Continuous exposure or a period of closure |
| Between April and September 2026 | No full continuous service history. A query of Netlas's 2026-07-22 index returned no items | The July result does not establish the service was closed |
| Netlas campaign labeled 2026-09-10 | Limited response lists SSH/22, MSRPC/135 and RDP/3389 | No per-service timestamp or identity was returned in that projection. The label is not proof the ports answered on September 10 |
| InternetDB collected September 28 | Lists TCP 3389 and self-signed tag, without a scan timestamp | Collection time is not observation time; missing SSH/SMB in that dataset does not prove they closed |
| Photograph's review cutoff, September 26 at 15:41:23 UTC-07 | Report describes prior preserved public-source failed-login evidence for FRED01, but the underlying login timestamps are not shown | No successful compromise, exposure start or remediation date can be inferred |
| After the September 25 SSH observation | No later dated positive service observation recovered | Current reachability or shutdown time |

The October and September endpoints span approximately eleven months in the recovered records. This is an observation span, not eleven months of proven uninterrupted exposure. A scanner's successful service response also does not prove successful user authentication or compromise.

## 70.182.52.122 — all recovered work-machine event times

The following are secondary evidence from the supplied photograph, not original event exports. Each is described as a successful outbound `msedge.exe` HTTPS connection from FRED02 / TEMDFIRPRDFRD02, local address `192.168.8.187`, using public egress `70.182.52.122`.

| Date/time UTC | Phoenix date/time | Remote destination | Source event ID |
|---|---|---|---|
| 2026-09-16 12:56:50.541 | 2026-09-16 05:56:50.541 | 150.171.28.11:443 | Not reliably legible; omitted |
| 2026-09-16 12:56:58.622 | 2026-09-16 05:56:58.622 | 150.171.109.149:443 | f4067feb-e656-47bd-a7ed-4b359d21fa60 |
| 2026-09-16 12:57:08.361 | 2026-09-16 05:57:08.361 | 150.171.27.11:443 | 5f478c47-e6b6-48a5-8894-2426fc7c6db3 |

Source: [photo transcription](evidence-photo/photo-transcription.md) and [excluded photograph provenance](photo-exclusion-record.json). These events establish the photographed report's account of outbound use; they do not establish publicly reachable SSH, RDP, SMB or any inbound listener on FRED02. The report explicitly leaves FRED02's current state unresolved.



No inbound service record for 70.182.52.122 was recovered from the successfully queried public sources. Missing records do not prove absence of exposure. Details are in [scan-source coverage](scan-history/scan-report.md).

## Network context and source coverage

RIPEstat returned routing visibility for the containing networks over September 29, 2025 through September 27, 2026. Registration identifies provider allocation blocks; neither routing nor registration timestamps establish whether either workstation accepted connections. [Routing and registration assessment](public-history/ripe_whois_dns_wayback.md)

The latest follow-up found no new dated service observations: exact public searches had no earlier service match, LeakIX displayed zero services, and the attempted Wayback/Common Crawl lookups failed. Restricted or inaccessible provider history remains an unresolved gap. [Updated external findings](01_EXTERNAL_FINDINGS.md)

At preparation time, 12:27 UTC-07 on September 28, the earlier Netlas daily-limit reset estimate of approximately 17:36 UTC-07 had not elapsed. The older 2024/2025 datasets remain unqueried, and no automatic later retry is scheduled. [Exact older-query candidates](followup-older/netlas-older-candidates.md)

The investigation still needs original firewall/NAT configuration changes, traffic/session logs and retained endpoint/SIEM records to establish activation, mapped machine identity, periods of interruption and removal. [Collection request](collection-request.md)

Machine-readable records are in [timeline.csv](timeline.csv) and [timeline.json](timeline.json). The original evidence bundle (not copied into this handoff) remains unchanged; the follow-up has its own [hash manifest](followup-older/sha256.csv).
