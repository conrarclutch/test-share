> Photo-free distribution: the supplied photograph and photographic copies are excluded. Written photo-derived evidence remains secondary evidence. Original image references and its SHA-256 are retained only as provenance; the image is not included. Historical statements about the original package do not describe this derivative. Use this distribution's manifest and metadata.

# Public registration, routing, DNS, and archive checks

Collection window requested: 2025-09-28 through 2026-09-28. RIPEstat response metadata timestamps place collection on 2026-09-28 around 18:22–18:24 UTC. The raw JSON files are in this directory.

## Findings

| IP | Public registration evidence | RIPE RIS route history | DNS as queried on 2026-09-28 |
|---|---|---|---|
| 38.122.88.139 | ARIN RDAP currently returns Cogent (`COGENT-A`) for 38.0.0.0/8. The record has a registration event dated 1991-04-15 and a last-changed event dated 2025-09-23. This is the provider’s aggregate allocation; it does not identify the customer/device assignment for this individual address. | RIPEstat returned origin AS174 for 38.0.0.0/8 during 2025-09-29 through 2026-09-27 in all returned segments passing `min_peers=10`. The response’s latest available BGP query time was 2026-09-28 08:00. The history has no returned segment for 2025-09-28. This is prefix routing evidence only. | No PTR: RIPEstat’s reverse lookup returned NXDOMAIN at 2026-09-28 18:22 UTC. |
| 70.182.52.122 | ARIN RDAP currently returns `NETBLK-PH-CBS-70-182-48-0`, range 70.182.48.0–70.182.55.255 (a /21), with registration and last-changed events dated 2024-05-13. The record does not name the work machine. | RIPEstat returned origin AS22773 for 70.182.48.0/20 and enclosing 70.160.0.0/11 during 2025-09-29 through 2026-09-27 in all returned segments passing `min_peers=10`. The response’s latest available BGP query time was 2026-09-28 08:00. No returned segment for 2025-09-28. This is prefix routing evidence only. | Current PTR is `wsip-70-182-52-122.ph.ph.cox.net`, a provider-style name, at 2026-09-28 18:23 UTC. It does not establish a historical hostname or machine identity. |

The RIPEstat routing-history request covered 2025-09-28T00:00:00 to 2026-09-28T23:59:59, but the response reported its latest data time as 2026-09-28T08:00:00 and its last full interval as 2026-09-27. Treat 2025-09-28 and the remainder of 2026-09-28 as uncovered by the returned intervals. The API documentation says `min_peers` filters route segments by RIS full-feed peer count; it is useful evidence that the containing prefix was visible in BGP, not evidence that a host answered, that a port was open, or that every address in the prefix was assigned.

RIPEstat’s `normalise_visibility` field returned a value above 1 in one interval. This report therefore uses the `min_peers=10` filter and interval bounds, and does not rely on normalized visibility percentages.

## DNS and historical archive coverage

RIPEstat `dns-chain` and `reverse-dns-ip` are current DNS lookups; they do not provide historical passive-DNS timelines. The lookups produced no PTR for 38.122.88.139 and a generic Cox PTR for 70.182.52.122. No historical DNS relationship is inferred from those current results.

For Wayback, the availability API was queried for the exact HTTP and HTTPS root URLs (`http://IP/` and `https://IP/`) at timestamps 2025-09-28 and 2026-09-28. All eight responses were HTTP 200 with an empty `archived_snapshots` object. That only covers the root URL and the API’s nearest-snapshot response. The broader CDX wildcard queries for each IP (`IP/*`, 2025–2026) returned HTTP 503 with the Internet Archive “Temporarily Offline” page. Therefore arbitrary-path CDX coverage was unavailable; the 503 is not evidence that no captures exist.

Exact public web searches run: `"38.122.88.139"`, `"70.182.52.122"`, `site:shodan.io/host "38.122.88.139" OR "70.182.52.122"`, and `site:urlscan.io "38.122.88.139" OR "70.182.52.122"`. Results included a generic IPinfo 38.122.88.0/24 range listing and a generic 70.182 range listing, but no dated reachability history from those search results. These snippets were not used as reachability evidence.

## Sources and raw results

- ARIN RDAP: `https://rdap.arin.net/registry/ip/38.122.88.139` and `https://rdap.arin.net/registry/ip/70.182.52.122` — saved as `38.122.88.139-rdap-arin.json` and `70.182.52.122-rdap-arin.json`.
- RIPEstat Routing History, with `normalise_visibility=true&min_peers=10`: `https://stat.ripe.net/data/routing-history/data.json?resource=38.122.88.139&starttime=2025-09-28T00:00:00&endtime=2026-09-28T23:59:59&normalise_visibility=true&min_peers=10` and the same URL with `resource=70.182.52.122`. Saved as `*-ripe-routing-history-min10.json`.
- Additional RIPEstat exploratory route-history requests with `include_first_hop=true&min_peers=1` are saved as `*-ripe-routing-history-min1-firsthop.json`; they include many low-visibility path variants and are not used for the concise timeline.
- RIPEstat current DNS chain: `https://stat.ripe.net/data/dns-chain/data.json?resource=IP` — saved as `*-ripe-dns-chain.json`.
- RIPEstat current reverse DNS: `https://stat.ripe.net/data/reverse-dns-ip/data.json?resource=IP` — saved as `*-ripe-reverse-dns-ip.json`.
- RIPEstat current Whois: `https://stat.ripe.net/data/whois/data.json?resource=IP` — saved as `*-ripe-whois.json`.
- Wayback availability results and response headers are saved as `*-wayback-available-*.json` and `*.headers.txt`; CDX 503 responses are saved as `*-wayback-cdx.json` and corresponding headers.

Method documentation: [RIPEstat Routing History](https://stat.ripe.net/docs/data-api/api-endpoints/routing-history), [RIPEstat Whois](https://stat.ripe.net/docs/data-api/api-endpoints/whois), [RIPEstat DNS Chain](https://stat-ui.stat.ripe.net/docs/data-api/api-endpoints/dns-chain.html), [RIPEstat Reverse DNS IP](https://m.stat.ripe.net/docs/data-api/api-endpoints/reverse-dns-ip.html), and [RIPEstat Data API](https://stat.ripe.net/docs/data-api/ripestat-data-api).
