> Photo-free distribution: the supplied photograph and photographic copies are excluded. Written photo-derived evidence remains secondary evidence. Original image references and its SHA-256 are retained only as provenance; the image is not included. Historical statements about the original package do not describe this derivative. Use this distribution's manifest and metadata.

# Package README and changelog

This is a local-only handoff package assembled from allowlisted evidence files and reports. Original source files remain unchanged in the workspace. The package manifest covers every packaged file except itself.

## Changelog

- 2026-09-28: Created the initial external handoff package and separate observation, identity, boundary, coverage, inventory, and integrity files.
- 2026-09-28: full-known-history.md: removed one unrelated private-account paragraph from the package copy.
- 2026-09-28: full-known-history.md: redirected an omitted old-report link to the current external findings report.
- 2026-09-28: full-known-history.md: removed a link to the excluded original nested ZIP.
- 2026-09-28: exposure-findings.md: removed one unrelated private-account paragraph from the package copy.
- 2026-09-28: access-coverage.md: removed one unrelated private-account coverage row from the package copy.
- 2026-09-28: Omitted full third-party documentation/article HTML snapshots; source inventory retains their file hashes and exclusion reasons.
- 2026-09-28: Included `ip-exposure-timeline.png` as an optional presentation aid; structured observations and raw source responses remain authoritative.
- 2026-09-28: Excluded private account artifacts, credentials, private keys, and unsanitized workspace documents.
