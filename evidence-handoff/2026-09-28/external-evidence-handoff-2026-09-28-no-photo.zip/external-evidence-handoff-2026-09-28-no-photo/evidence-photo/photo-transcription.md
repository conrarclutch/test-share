> Photo-free distribution: the supplied photograph and photographic copies are excluded. Written photo-derived evidence remains secondary evidence. Original image references and its SHA-256 are retained only as provenance; the image is not included. Historical statements about the original package do not describe this derivative. Use this distribution's manifest and metadata.

# Photo-derived report transcription

**Evidence grade:** `SECONDARY_PHOTOGRAPH`

**Source:** `source-photo.jpg`  
**SHA-256:** `B6D403C726E8A6AB29E9A2D19E9EE717DB33B9DDE5C6C2157B1C807139153EB9`

This is a photograph of a report displayed on a monitor, not an export from Exabeam, Falcon, or another source system. The statements below are transcribed from the visible report and have not been independently validated.

## Report identity and scope

- **Title:** “Other DFIR devices: internet exposure follow-up”
- **Reported review cutoff:** September 26, 2026, 15:41:23 UTC-07
- **Time convention:** The report says times use UTC-07 unless otherwise identified.
- **Headline:** It identifies workstation `TEMDFIRPRDFRD02` as having confirmed historical outbound internet connections. It says the same public-facing SSH/SMB/RDP exposure and public-source login-attempt pattern as `FRED01` has not been established, and cautions against classifying `FRED02` as equivalently exposed solely because it has a public egress address.

## Report-listed devices and public egress addresses

| Device shown | Report-listed public egress IP | Visible report context |
|---|---|---|
| `TEMDFIRPRDFRD01` (`FRED01`) | `38.122.88.139` | Prior inquiry: external-source failed authentication plus public-destination connections; public-source failed logons are described as confirmed in preserved case evidence. |
| `TEMDFIRPRDFRD02` (`FRED02`) | `70.182.52.122` | Follow-up: successful outbound `msedge.exe` HTTPS connections from local IP `192.168.8.187`. |

For `FRED02`, the comparison table says no public-source failed logons were identified in 16 returned records; known sources were private or loopback and other sources were missing. It lists one case / 36 alerts, including Case 15589 (risk 92, closed). Current state is described as unresolved, with no matching CrowdStrike telemetry after September 16 in the tested fields.

## Visible direct-connection rows

The report lists three successful outbound events for `TEMDFIRPRDFRD02`, process `msedge.exe`, local IP `192.168.8.187`, public egress `70.182.52.122`:

| Time (UTC-07) | Remote destination | Event ID |
|---|---|---|
| `2026-09-16T05:56:58.622-07:00` | `150.171.109.149:443` | `f4067feb-e656-47bd-a7ed-4b359d21fa60` |
| `2026-09-16T05:57:08.361-07:00` | `150.171.27.11:443` | `5f478c47-e6b6-48a5-8894-2426fc7c6db3` |
| `2026-09-16T05:56:50.541-07:00` | `150.171.28.11:443` | Not transcribed: the ID is not unambiguously legible in the photograph. |

The explanatory text says the three records have `outcome=success` and `direction=outbound`, and that raw Falcon fields confirm the local address and listed remote addresses. It explicitly says these events do not identify an internet activation time or demonstrate publicly listening services.

## Limits for a reachability timeline

This photo supports that the report listed the two egress addresses above and that it described three outbound connections at the precise displayed times. It does not show when either address was first or last publicly reachable, whether inbound ports were open, or the duration of any exposure. The report also says `FRED02`'s state is unresolved after September 16 in the tested CrowdStrike fields. Treat the content as secondary evidence until checked against original logs and cloud/network configuration history.
