> Photo-free distribution: the supplied photograph and photographic copies are excluded. Written photo-derived evidence remains secondary evidence. Original image references and its SHA-256 are retained only as provenance; the image is not included. Historical statements about the original package do not describe this derivative. Use this distribution's manifest and metadata.

# External findings and exposure boundaries

Targets: `38.122.88.139` and `70.182.52.122`. Prepared September 28, 2026; the package metadata records the final cutoff. This report distinguishes service evidence, identity evidence, secondary photo evidence, and source-coverage gaps.

ON/OFF in this report means availability of the specified service through the specified public network path, not whether the computer was powered on. Record restrictions such as source allowlists separately from unrestricted internet access.

## Supported conclusions

**38.122.88.139:** RDP and SSH response records were indexed by Netlas in October 2025 and April 2026. Shodan collected RDP, SMB and SSH responses in September 2026. RDP repeatedly reports the FRED01 machine name. The SSH public-key bytes match across October, April and September. These are affirmative service-response observations, not proof of successful authentication, compromise or uninterrupted availability.

**70.182.52.122:** the supplied report photograph describes three outbound HTTPS successes by FRED02 on September 16, 2026. No inbound service observation for this IP was recovered. The public IP may be shared egress or translated; its association with one machine requires dated internal mapping evidence.

**ON/OFF status:** the true activation time, removal time and all intermediate state changes remain unresolved for both addresses. No public record recovered establishes a defensible continuous ON or OFF interval. The first positive record is an observed historical boundary, not a creation/enable audit event; the last positive is not a shutdown event.

## Positive service observations for 38.122.88.139

All table times are UTC. Phoenix display times in the structured data use UTC-07.

| Evidence ID / source | Timestamp | Timestamp meaning | Service | Response detail |
|---|---|---|---|---|
| Netlas October RDP | 2025-10-25T12:30:55.903Z | Document indexed | TCP/3389 RDP | TEMDFIRPRDFRD01 / temdfirprdfrd01; build 10.0.22621 |
| Netlas October SSH | 2025-10-25T14:42:39.991Z | Document indexed | TCP/22 SSH | OpenSSH_for_Windows_9.5; ECDSA host key |
| Netlas April RDP | 2026-04-21T19:28:56.883Z | Document indexed | TCP/3389 RDP | Same response names and build |
| Netlas April SSH | 2026-04-21T22:20:47.460Z | Document indexed | TCP/22 SSH | Same banner and public-key bytes |
| SHODAN-3389 | 2026-09-13T09:06:24Z | Banner collected | TCP/3389 RDP | Same response names and build |
| SHODAN-445 | 2026-09-24T10:19:19Z | Banner collected | TCP/445 SMB | SMB v2, authentication enabled; internal destination unverified |
| SHODAN-22 | 2026-09-25T18:18:50Z | Banner collected | TCP/22 SSH | Same banner and public-key bytes |

Exact stable evidence IDs, source paths and SHA-256 references are in `external-observations.json`. The Netlas source campaigns are labeled 2025-10-22 and 2026-04-19; those labels are not the target's exact probe dates. The October RDP response reports a remote clock of 2025-10-25T12:30:42+00:00, and April reports 2026-04-21T20:29:06+00:00. The April clock is roughly an hour ahead of the index time. Neither remote clock is used as an independent timestamp.

An additional limited Netlas response lists TCP/135 MSRPC, TCP/22 SSH and TCP/3389 RDP in the campaign labeled 2026-09-10. It contains no per-service timestamp. InternetDB separately lists TCP/3389 without a scan timestamp. These are retained as undated evidence, not assigned the retrieval or campaign-start date.

## Identity correlation

The observed SSH ECDSA P-256 fingerprint is `SHA256:J/2BW66rF1U9FqOfuLUBcTRfaplCXE8Mb6z6/vVc0c4`; the SHA-256 hex form is `27fd815baeab17553d16a39fb8b50171345f6a99425c4f0c6facfafef55cd1ce`. The reconstructed public key is in `followup-ssh-key/observed-ssh-ecdsa.pub`. Only public identity material is supplied; no private key is needed for comparison.

Matching key bytes support the same service-key identity, but keys can be cloned or retained through rebuilds. Repeated RDP machine names are corroboration, not a stable hardware/EDR identifier. SMB and MSRPC cannot be attributed to the same internal endpoint solely because they share the public IP.

The September RDP banner also reports a self-issued certificate with issuer and subject CN `temdfirprdfrd01`, serial `52:a1:21:bd:04:a9:a3:89:46:f8:e1:53:ad:84:00:41`, and validity dates April 25 to October 25, 2026. These fields are a local-certificate/backup comparison lead. Validity is not issuance observation or public exposure time. See `audit/identity-pivots/` for the source extraction and new passive checks.

## Photo-derived FRED02 events

All three events are secondary evidence from the supplied photograph: `msedge.exe`, local IP `192.168.8.187`, public egress `70.182.52.122`, outbound success.

| UTC event time | Destination | Source event ID |
|---|---|---|
| 2026-09-16T12:56:50.541Z | 150.171.28.11:443 | Unverified / omitted |
| 2026-09-16T12:56:58.622Z | 150.171.109.149:443 | f4067feb-e656-47bd-a7ed-4b359d21fa60 |
| 2026-09-16T12:57:08.361Z | 150.171.27.11:443 | 5f478c47-e6b6-48a5-8894-2426fc7c6db3 |

Obtain the originals from Falcon/Exabeam and verify fields, source IDs, direction and time. The third photo ID remains null in the structured evidence because legibility is insufficient; a review note may offer a tentative transcription only. The photograph's September 26 review cutoff is report metadata, not a network change. Its narrative about prior public-source failed logins on FRED01 supplies an internal case lead without the underlying timestamps.

## Earlier history and failed/negative checks

The saved Netlas catalog lists older response datasets 2025-03-21, 2024-10-23 and 2024-04-25. No target-specific result from them has been obtained; their existence must not backdate exposure. The earlier quota response estimated reset around 2026-09-29T00:36:10Z. No retry bypass or additional account was used. Authorized work-use access remains a separate consideration.

Completed no-result checks, restricted/authenticated sources, quota blocks and transport failures are recorded separately in the package. In particular, the July 2026 Netlas no-hit and LeakIX's zero displayed services do not establish closure. Archive failures do not establish that captures never existed. BGP routing, provider allocation, current reverse DNS and certificate validity are contextual identity leads; none proves a responding port.

Additional independent searches and their exact responses are in `audit/new-public-records/` and `audit/identity-pivots/`. Interpret a new source's result using its own timestamp semantics and account/coverage limits. Any newly accepted dated service evidence must appear in `external-observations.json`; an access log or query-preview file alone is not a positive observation.

The independent pass added these documented outcomes, with no new dated service observation:

| Additional source | Result | Interpretation |
|---|---|---|
| BinaryEdge historical host route, both IPs | HTTP 410 | Endpoint unavailable; no historical answer obtained |
| ONYPHE exact-IP API search, both IPs | HTTP 400, no API key | Authentication/access gap, not zero matching records |
| Current Censys v3 host lookup, both IPs | HTTP 401 | No authorized response obtained; this does not establish absence |
| crt.sh exact hostname/IP checks | Empty results | No matching certificate-transparency result recovered; not a test of RDP/SSH availability |
| Internet Archive availability checks for exact Shodan URLs/dates | No available snapshots returned | No additional archived page from these specific checks; not exhaustive archive absence |
| Current reverse-IP lookups | No primary hostname; secondary provider PTR only | Current naming context only |
| Cogent RWhois | Syntax errors, timeout or no objects for attempted queries | No subscriber assignment recovered; no machine identity inferred |

Existing ARIN material identifies provider-level allocation handles `NET-38-0-0-0-1` / `COGENT-A` for the primary address and `NET-70-182-48-0-1` / `NETBLK-PH-CBS-70-182-48-0` for the secondary. These can help the internal network team locate allocation records, but are not workstation assignments or exposure dates.

## Internal evidence needed for credible on/off bounds

For every service, identify the public assignment and complete ingress path at the observation time: firewall interface/zone, forwarding rule/version, translated destination, private address lease, stable endpoint ID and listening service. Compare configuration snapshots before/after the observed dates, and retrieve change records including effective deployment time, actor account and rollback. Pair them with actual accepted/established traffic and retained endpoint logs.

Keep configuration-enabled time distinct from first responding-service time. For shutdown, seek affirmative path removal or service cessation with scope and corroboration; verify no alternative mapping/path or replacement host remained. Record multiple cycles where supported. If the evidence can only bracket a transition, give the bracket and supporting records rather than a guessed exact time. Silence, missing scans and expired logs remain gaps.

Independent raw-evidence review found no contradictory positive claim. Its low-level qualifications and the coverage review are included under `audit/`. The new package manifest includes later reports as well as original evidence; the earlier manifest naturally predates those additions.
