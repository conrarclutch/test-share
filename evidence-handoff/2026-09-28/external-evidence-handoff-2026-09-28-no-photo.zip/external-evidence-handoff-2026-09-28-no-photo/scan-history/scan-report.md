> Photo-free distribution: the supplied photograph and photographic copies are excluded. Written photo-derived evidence remains secondary evidence. Original image references and its SHA-256 are retained only as provenance; the image is not included. Historical statements about the original package do not describe this derivative. Use this distribution's manifest and metadata.

# Public scan history: 38.122.88.139 and 70.182.52.122

Lookup window: 2025-09-28 through 2026-09-28. All collected bodies and errors are retained beside per-request metadata in this folder. Metadata records the exact URL, UTC access time, HTTP status, and whether the lookup was unauthenticated. These were passive queries to existing public datasets; no direct probes or new scan submissions were made.

## Positive service observations

| UTC time | IP and service | Source and qualification |
|---|---|---|
| 2025-10-25 12:30:55.903Z | 38.122.88.139 TCP/3389 RDP | Netlas `@timestamp` from explicit public index `2025-10-22`. RDP/NTLM fields identify `TEMDFIRPRDFRD01` / `temdfirprdfrd01`; the server-reported system clock was 12:30:42Z. |
| 2025-10-25 14:42:39.991Z | 38.122.88.139 TCP/22 SSH | Netlas `@timestamp`, index `2025-10-22`; banner `SSH-2.0-OpenSSH_for_Windows_9.5`. |
| 2026-04-21 19:28:56.883Z | 38.122.88.139 TCP/3389 RDP | Netlas `@timestamp`, explicit index `2026-04-19`; same RDP target name. The remote system clock reported 20:29:06Z, about 1 hour 9 seconds after the index timestamp. Keep these as separate clocks. |
| 2026-04-21 22:20:47.460Z | 38.122.88.139 TCP/22 SSH | Netlas `@timestamp`, index `2026-04-19`. |
| 2026-09-13 09:06:24Z | 38.122.88.139 TCP/3389 RDP | Shodan host banner timestamp; NTLM name matches `TEMDFIRPRDFRD01`. |
| 2026-09-24 10:19:19Z | 38.122.88.139 TCP/445 SMB | Shodan host banner timestamp; banner reports SMB v2 and authentication enabled. |
| 2026-09-25 18:18:50Z | 38.122.88.139 TCP/22 SSH | Shodan host banner timestamp; OpenSSH for Windows 9.5. Shodan's host page also showed “Last Seen: 2026-09-25.” |

Shodan's Datapedia defines its banner `timestamp` as the UTC date and time the banner was collected. Netlas defines `@timestamp` as the time its document was indexed, usually close to scan time; it is not an exact probe time. Netlas also labels `scan_date`, which its documentation marks as deprecated, and separately reports the remote system clock for the RDP banner. [Shodan Datapedia](https://datapedia.shodan.io/) · [Netlas Responses fields](https://docs.netlas.io/knowledge-base/field-reference/responses/)

The first positive point found inside the requested year is 2025-10-25. This is the earliest observation found in the queried public datasets, not an exposure start date. The snapshots do not establish continuous reachability between observations or an exact close time.

A latest-index Netlas lookup and host summary list TCP/22 SSH, TCP/135 MSRPC, and TCP/3389 RDP for 38.122.88.139. The source index is labeled `2026-09-10`, with a dataset scan window from 2026-09-10T00:00:00Z through 2026-09-28T18:12:31.645Z. Netlas did not return per-service timestamps for these three items in the limited-field response; those index-wide dates are not host observation times. Shodan's unauthenticated host view showed the same recent SSH, SMB, and RDP services.

## No public scan observation found for 70.182.52.122

Shodan InternetDB and its public host page say no information is available. Netlas's current host record contains WHOIS/ASN/registration data but no service ports, the latest response search returned no items, and an explicit query over the available selected response indexes returned `items: []`. GreyNoise Community returned 404 and urlscan returned zero results. These are provider-specific no-result responses; they do not establish that the IP was never reachable or that a port was closed. The parent investigation separately has a sign-in event using this IP as a source address; that alone does not identify a publicly listening host.

## Provider access and limits

- **Shodan:** InternetDB returned TCP/3389 and a `self-signed` tag for 38.122.88.139, without a timestamp. The public host page supplied the dated banners above. Unauthenticated `/history` and `/raw` requests returned 401. Shodan says its regular host views show recent banners within 30 days and historical IP lookup is limited to 90 days / 1,000 banners. Trends provides multi-year aggregates; historical raw bulk data is a separate enterprise option. Aggregates cannot replace timestamped host observations. No account or credits were used. [Shodan data timeframes](https://help.shodan.io/mastery/data_timeline)
- **Netlas:** Public response snapshots available from its index listing within the year included labels `2025-10-22`, `2026-04-19`, `2026-07-22`, `2026-08-07`, `2026-08-21`, and `2026-09-10`. Explicit queries for 2025-10-22 and 2026-04-19 returned matching labels and service details. A 2026-07-22 request first timed out at 20 seconds; one retry returned HTTP 200 with `items: []`. A multi-index request for 38.122.88.139 timed out at 40 seconds. Queries for 2026-08-07 and 2026-08-21 were not completed. An explicit 2026-09-10 query returned HTTP 429, `daily_request_limit_exceeded`, so I stopped further Netlas calls. The default latest query had returned the 2026-09-10-labeled result before the limit; it had a restricted field projection and omitted `@timestamp`. The combined explicit six-index query for 70.182.52.122 returned HTTP 200 with no items. An available response index from 2025-03-21, before the requested year, was not queried after the service limit.
- **GreyNoise:** Both unauthenticated Community API requests returned HTTP 404 (“unable to find a record”). Public visualizer requests returned HTTP 403.
- **urlscan:** Public IP search returned HTTP 200, `total: 0`, for each address.
- **Censys:** Unauthenticated current-host API requests returned HTTP 401; the attempted legacy host-events route returned 404; public host pages returned 403. No historical Censys data was available without an account/API credential.
- **VirusTotal:** Unauthenticated IP API returned HTTP 401 for each address. The public GUI URL returned only its JavaScript shell, with no rendered report in the saved response.
- **FOFA:** Unauthenticated search API returned HTTP 200 with `[-700] 账号无效` (“invalid account”); the public UI request ended with a saved transport error.
- **ZoomEye:** The `.org` API returned HTTP 403 stating the endpoint was unavailable in this region and naming `api.zoomeye.ai`; that endpoint returned HTTP 502 for both addresses. The public search UI returned HTTP 521.

The detailed per-service timeline with timestamp semantics is in [normalized-events.json](normalized-events.json). The raw provider responses and matching `.meta.json` files are stored in this folder.
