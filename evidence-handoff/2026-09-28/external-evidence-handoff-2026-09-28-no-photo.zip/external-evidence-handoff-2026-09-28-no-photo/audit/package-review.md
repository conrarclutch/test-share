# Photo-free distribution review

This derivative excludes the supplied photograph. Written secondary evidence and the original image hash remain for provenance. The separate timeline infographic was visually reviewed and contains no photograph.

The source archive was verified against SHA-256 `97f9f55ee1d10f344b2dec91565cd6fa3039f066b1306ec9a9900179cdfc59c6` before transformation. Raw provider responses and observation dates are unchanged. The original source archive remains local and is not nested in this distribution.

Use [verify_photo_free_handoff.py](verify_photo_free_handoff.py) against this ZIP and its adjacent checksum file. The final check verifies the archive CRC, manifest, retained source hashes, explicit excluded-image provenance, structured data, and local Markdown links. Independent final verification results are recorded outside the archive after creation.
