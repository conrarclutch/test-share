> Photo-free distribution: the supplied photograph and photographic copies are excluded. Written photo-derived evidence remains secondary evidence. Original image references and its SHA-256 are retained only as provenance; the image is not included. Historical statements about the original package do not describe this derivative. Use this distribution's manifest and metadata.

# External-query handoff

No request was executed for this handoff. Exact URLs and per-query status are in [`pending-external-queries.json`](pending-external-queries.json).

For `38.122.88.139`, run the candidate indices in this order only if the investigation scope includes older-than-year history and Netlas quota plus organizational work-use entitlement are confirmed: `2025-03-21` first (earliest boundary lead), then the in-year `2026-08-07` and `2026-08-21` indices, then `2024-10-23` and `2024-04-25` only if an even earlier period matters. A combined-index attempt containing the two August dates timed out; each individual lookup remains `NOT_RUN`. The explicit `2026-09-10` request returned HTTP 429 `daily_request_limit_exceeded` and is `BLOCKED_QUOTA`, not a negative result.

For `70.182.52.122`, only the three older candidate indices (`2025-03-21`, `2024-10-23`, `2024-04-25`) remain unqueried. Its selected six-index query covering `2025-10-22`, `2026-04-19`, `2026-07-22`, `2026-08-07`, `2026-08-21`, and `2026-09-10` already returned HTTP 200 with `items: []`; do not mark those dates pending or repeat that query as if it were missing.

Netlas's earlier reset estimate is `2026-09-29T00:36:10Z`, not independently verified. Do not automatically retry or treat the estimate as current authorization. Netlas Community is documented for personal/non-commercial use; confirm quota reset and an appropriate organizational entitlement before any workplace query. No-host-hit status remains unknown for all unrun requests. Index availability/full status is catalog metadata only, and any future `@timestamp` is an indexing time, not an exact probe time.

Check original internal firewall/NAT, edge flow/session, configuration-change, Falcon, and Exabeam exports first. Censys historical host data, Shodan history/raw data, and Shadowserver reports are access-dependent leads only; access and one-year history are not guaranteed. Preserve returned data with exact request URL, UTC retrieval time, HTTP status, raw response, and completeness/pagination details. Do not claim that these queries would capture all public records or prove continuous exposure.
