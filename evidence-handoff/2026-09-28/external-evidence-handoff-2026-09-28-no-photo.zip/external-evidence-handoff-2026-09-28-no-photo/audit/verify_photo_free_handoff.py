#!/usr/bin/env python3
"""Verify a photo-free derivative ZIP against its own manifest and provenance."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path, PurePosixPath

PACKAGE = "external-evidence-handoff-2026-09-28-no-photo"
RAW_HTML_ERRORS = {
    f"{PACKAGE}/followup-older/datasets/censys-v1_ipv4_38.122.88.139.json",
    f"{PACKAGE}/followup-older/datasets/censys-v1_ipv4_70.182.52.122.json",
    f"{PACKAGE}/public-history/38.122.88.139-wayback-cdx.json",
    f"{PACKAGE}/public-history/70.182.52.122-wayback-cdx.json",
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def fail(message: str) -> None:
    raise ValueError(message)


def verify(zip_path: Path) -> dict[str, object]:
    if not zip_path.is_file():
        fail(f"ZIP does not exist: {zip_path}")
    sidecar = zip_path.with_suffix(zip_path.suffix + ".sha256")
    if not sidecar.is_file():
        fail(f"Missing SHA-256 sidecar: {sidecar}")
    sidecar_text = sidecar.read_text(encoding="ascii").strip()
    match = re.fullmatch(r"([0-9a-fA-F]{64})\s+\*?(.+)", sidecar_text)
    if not match or match.group(2).strip() != zip_path.name:
        fail("SHA-256 sidecar must contain the ZIP filename and one 64-digit digest")
    archive_hash = digest(zip_path.read_bytes())
    if archive_hash.lower() != match.group(1).lower():
        fail("ZIP SHA-256 does not match its sidecar")

    with zipfile.ZipFile(zip_path, "r") as zf:
        if bad := zf.testzip():
            fail(f"ZIP CRC check failed for {bad}")
        names = [info.filename for info in zf.infolist() if not info.is_dir()]
        if len(names) != len(set(names)) or len({n.casefold() for n in names}) != len(names):
            fail("ZIP contains duplicate paths")
        for name in names:
            p = PurePosixPath(name)
            if "\\" in name or p.is_absolute() or ".." in p.parts or not p.parts or p.parts[0] != PACKAGE:
                fail(f"Unsafe or unexpected ZIP path: {name}")
        manifest_name = f"{PACKAGE}/manifest-sha256.csv"
        if manifest_name not in names:
            fail("Embedded manifest is missing")
        manifest_rows = list(csv.DictReader(zf.read(manifest_name).decode("utf-8-sig").splitlines()))
        listed = {r["path"]: r for r in manifest_rows}
        actual = {n[len(PACKAGE) + 1:]: n for n in names if n != manifest_name}
        if set(actual) != set(listed):
            fail("Manifest/file set differs")
        contents: dict[str, bytes] = {}
        for rel, full_name in actual.items():
            data = zf.read(full_name)
            contents[rel] = data
            row = listed[rel]
            if int(row["bytes"]) != len(data) or row["sha256"] != digest(data):
                fail(f"Manifest size/hash mismatch: {rel}")

    image_suffixes = {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".tif", ".tiff"}
    images = sorted(p for p in contents if Path(p).suffix.lower() in image_suffixes)
    if images != ["ip-exposure-timeline.png"]:
        fail(f"Unexpected image assets in photo-free distribution: {images}")
    if "evidence-photo/source-photo.jpg" in contents or "audit/verify_handoff.py" in contents:
        fail("Original image or full-photo verifier remains in the derivative")
    if "audit/package-review.md" not in contents or "audit/verify_photo_free_handoff.py" not in contents:
        fail("Derivative review or verifier is missing")
    if any("supplemental-private" in p.lower() for p in contents):
        fail("Private supplemental path was packaged")

    exclusion = json.loads(contents["photo-exclusion-record.json"])
    if exclusion.get("distribution_status") != "EXCLUDED_FROM_DISTRIBUTION":
        fail("Photo exclusion status is missing")
    photo_path = exclusion.get("original_source_path", "")
    photo_hash = exclusion.get("original_source_sha256", "")
    if photo_path != "evidence-photo/source-photo.jpg" or not re.fullmatch(r"[0-9a-f]{64}", photo_hash.lower()):
        fail("Original photo provenance path/hash is invalid")

    metadata = json.loads(contents["package-metadata.json"])
    transform = json.loads(contents["photo-free-transformation.json"])
    if metadata.get("package_name") != PACKAGE or not metadata.get("photo_original_excluded"):
        fail("Photo-free package metadata is inconsistent")
    if metadata.get("source_package_sha256") != transform.get("source_package_sha256"):
        fail("Transformation/source package hashes disagree")

    observations = json.loads(contents["external-observations.json"])
    rows = observations.get("rows", [])
    if len(rows) != 15 or observations.get("source_timeline_rows") != 15:
        fail("Expected exactly 15 timeline observation rows")
    for row in rows:
        source_path = row.get("original_source_path", "")
        source_hash = row.get("original_source_sha256", "")
        if not source_path or not source_hash:
            fail(f"Observation lacks original source provenance: {row.get('evidence_id')}")
        if source_path == photo_path:
            if row.get("source_distribution_status") != "EXCLUDED_FROM_DISTRIBUTION" or row.get("packaged_source_path"):
                fail(f"Excluded photo is represented as packaged source: {row.get('evidence_id')}")
            if source_hash.lower() != photo_hash.lower():
                fail(f"Photo source hash mismatch: {row.get('evidence_id')}")
        else:
            if row.get("source_distribution_status") != "INCLUDED_IN_DISTRIBUTION":
                fail(f"Included source status missing: {row.get('evidence_id')}")
            if source_path not in contents or digest(contents[source_path]) != source_hash:
                fail(f"Observation source hash mismatch: {row.get('evidence_id')}")
        if row.get("timestamp_role") == "DOCUMENT_INDEX_TIME_NOT_EXACT_SCAN_TIME" and row.get("observational_time_utc"):
            fail(f"Index time was promoted to observation time: {row.get('evidence_id')}")
        if row.get("direction") == "outbound" and "OUTBOUND_ONLY_DOES_NOT_ESTABLISH_INBOUND_REACHABILITY" not in row.get("quality_flags", []):
            fail(f"Outbound qualification is missing: {row.get('evidence_id')}")

    invalid_json = []
    for rel, data in contents.items():
        if rel.lower().endswith(".json"):
            try:
                json.loads(data.decode("utf-8-sig"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                invalid_json.append(f"{PACKAGE}/{rel}")
    if set(invalid_json) != RAW_HTML_ERRORS:
        fail(f"Unexpected invalid .json payloads: {sorted(invalid_json)}")

    csv_rows: dict[str, list[dict[str, str]]] = {}
    for rel, data in contents.items():
        if rel.lower().endswith(".csv"):
            csv_rows[rel] = list(csv.DictReader(data.decode("utf-8-sig").splitlines()))
    if len(csv_rows.get("timeline.csv", [])) != 15 or len(csv_rows.get("external-observations.csv", [])) != 15:
        fail("Timeline and external-observations CSVs must each have 15 rows")
    if len(csv_rows.get("external-boundaries.csv", [])) != 5:
        fail("Expected five boundary rows")

    inventory = list(csv.DictReader(contents["source-inventory.csv"].decode("utf-8-sig").splitlines()))
    excluded = [r for r in inventory if r.get("source_path") == photo_path]
    if len(excluded) != 1 or excluded[0].get("inclusion_status") != "EXCLUDED_PHOTO_ORIGINAL" or excluded[0].get("package_path"):
        fail("Source inventory lacks one explicit excluded-photo record")
    if excluded[0].get("sha256", "").lower() != photo_hash.lower():
        fail("Source inventory's excluded-photo SHA-256 disagrees")
    for row in inventory:
        if row.get("inclusion_status") == "INCLUDED" and row.get("package_path"):
            path = row["package_path"]
            if path not in contents or digest(contents[path]) != row.get("sha256"):
                fail(f"Source inventory hash mismatch: {path}")

    broken_links = []
    for rel, data in contents.items():
        if not rel.lower().endswith(".md"):
            continue
        text = data.decode("utf-8", errors="replace")
        for target in re.findall(r"\]\(([^)]+)\)", text):
            target = target.split("#", 1)[0]
            if not target or re.match(r"^[a-z]+://", target, re.I) or target.startswith("mailto:"):
                continue
            normalized = str(PurePosixPath(rel).parent / target)
            normalized = str(PurePosixPath(normalized))
            if normalized not in contents and normalized != "manifest-sha256.csv":
                broken_links.append((rel, target))
    if broken_links:
        fail(f"Broken local Markdown links: {broken_links}")

    return {
        "zip": str(zip_path), "zip_sha256": archive_hash,
        "zip_files_including_manifest": len(names), "manifest_entries": len(listed),
        "crc": "PASS", "manifest": "PASS", "photo_excluded": "PASS",
        "photo_provenance_hash": photo_hash, "observation_source_hashes": "PASS",
        "generated_csv_json": "PASS", "source_inventory_hashes": "PASS",
        "markdown_links": "PASS", "documented_raw_html_error_payloads": invalid_json,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("zip", nargs="?", type=Path, default=Path(f"{PACKAGE}.zip"))
    args = parser.parse_args()
    try:
        result = verify(args.zip.resolve())
    except Exception as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
