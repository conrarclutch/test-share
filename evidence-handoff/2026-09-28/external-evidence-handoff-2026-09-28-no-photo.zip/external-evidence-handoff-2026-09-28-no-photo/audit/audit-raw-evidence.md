> Photo-free distribution: the supplied photograph and photographic copies are excluded. Written photo-derived evidence remains secondary evidence. Original image references and its SHA-256 are retained only as provenance; the image is not included. Historical statements about the original package do not describe this derivative. Use this distribution's manifest and metadata.

# Raw evidence audit

**Result: PASS with one transcription qualification.** I compared `full-known-history.md`, `exposure-findings.md`, and `timeline.json` to the preserved Netlas and Shodan response bodies, request metadata, normalized records, and the original report photograph. No positive scanner timestamp, UTC−07 conversion, service, SSH fingerprint, RDP name/build, or stated limitation was found to contradict the cited source.

## Checks

- **Netlas dates:** October 2025 and April 2026 explicit-index responses echo the requested labels. Their per-document `@timestamp` values match the timeline; UTC−07 values are exactly seven hours earlier. The separate NTLM clock values are correctly treated as untrusted remote clocks (October `12:30:42Z`; April `20:29:06Z`). These are indexing times, not exact probe-start times.
- **SSH identity:** October and April Netlas records have identical ECDSA public-key `raw` bytes and SHA-256 hex `27fd815baeab17553d16a39fb8b50171345f6a99425c4f0c6facfafef55cd1ce`; September 25 Shodan displays the same base64 key and matching colon-delimited MD5. The stated OpenSSH SHA256 fingerprint `SHA256:J/2BW66rF1U9FqOfuLUBcTRfaplCXE8Mb6z6/vVc0c4` agrees with the saved identifiers. This ties the observed SSH key across records but does not prove one physical endpoint or continuous availability.
- **RDP identity/build:** October and April Netlas records, and the September 13 Shodan banner, report `TEMDFIRPRDFRD01` / `temdfirprdfrd01` and build `10.0.22621`. These are service-reported names; NAT mapping and endpoint identifiers remain necessary for definitive attribution.
- **SMB and TCP/135:** Shodan's dated September 24 banner supports SMB v2 with authentication enabled on public IP `38.122.88.139`; it does not establish the internal target. The Netlas September-labeled search returns TCP/135, 22 and 3389 with no per-service observation timestamp. The handoff correctly does not assign September 10 as the observation date.
- **Negative results and gaps:** The documents consistently distinguish provider no-hits, unavailable/authentication-limited sources, unqueried indexes, and absent internal records from proof of closed ports. The September 28 InternetDB collection time is not treated as a scan time. No activation date, continuous interval, shutdown time, or successful compromise is inferred.
- **Photo events:** The two transcribed event IDs match the photo and `photo-events.json`; times and UTC conversion are correct. The photo itself appears to show a UUID in the third row (candidate transcription: `497072c4-dd01-4866-af9b-a68f87768c2b`), although image legibility is marginal. Keeping the event ID null/omitted pending original Falcon-log verification is conservative and appropriate. The photo remains secondary evidence for all three rows.
- **Integrity:** Current SHA-256 values and byte counts matched every entry in `sha256-work.csv` (including `timeline.json`, the photo, and normalized events). `full-known-history.md` is not listed in that manifest, so the handoff's newest narrative file is not integrity-anchored by that manifest.

## Source paths reviewed

- `full-known-history.md`; `exposure-findings.md`; `timeline.json`
- `scan-history/38.122.88.139-netlas-responses-2025-10-22-no-key.response` and `.meta.json`
- `scan-history/38.122.88.139-netlas-responses-2026-04-19-no-key.response` and `.meta.json`
- `scan-history/38.122.88.139-netlas-responses-search-no-key.response`
- `scan-history/38.122.88.139-shodan-public-host-page.response` and `.meta.json`
- `scan-history/38.122.88.139-shodan-internetdb.response`; `scan-history/normalized-events.json`; `scan-history/scan-report.md`
- `evidence-photo/source-photo.jpg`; `evidence-photo/photo-events.json`; `evidence-photo/photo-transcription.md`
- `followup-ssh-key/fingerprint-identifiers.json`; `sha256-work.csv`

## Remaining high-impact facts to obtain

Original firewall/NAT rule history and accepted-session logs are still needed to prove which internal endpoint received each inbound service and to bound activation, interruption, and removal. Original Exabeam/Falcon exports are needed to validate photo-derived event fields and the prior failed-logon account. For the third photo row, verify its event ID against Falcon before replacing the null transcription. No raw evidence reviewed here establishes FRED02 inbound exposure.
